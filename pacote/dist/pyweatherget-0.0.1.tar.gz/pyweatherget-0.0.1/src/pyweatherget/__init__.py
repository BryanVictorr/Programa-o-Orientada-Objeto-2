from pyweatherget import *
