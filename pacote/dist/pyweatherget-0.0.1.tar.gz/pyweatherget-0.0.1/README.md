pyweatherget
===========

#### Esse é um pacote para obter dados sobre clima e previsões do tempo
#### Veja um exemplo

## Instalação:

pip install pyweatherget

## Uso:

import pyweatherget


